package com.epam.multithreading.entity;

public class Book {
	
	private int id;
	private String name;
	private String author;
	private boolean canTake;

	public Book(int id, String name, String author, boolean canTake) {
		setID(id);
		setName(name);
		setAuthor(author);
		setCanTake(canTake);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public boolean isCanTake() {
		return canTake;
	}

	public void setCanTake(boolean canTake) {
		this.canTake = canTake;
	}

	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}

}
